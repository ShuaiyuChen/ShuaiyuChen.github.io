---
# Documentation: https://sourcethemes.com/academic/docs/managing-content/

title: "Idiosyncratic Volatility and Fund Performance: When Does It Pay to Use Active Managers?"
authors: [Shuaiyu Chen]
date: "2021-06-30"
doi: ""
weight: 20

# Schedule page publish date (NOT publication's date).
publishDate: "2021-06-30"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["3"]

# Publication name and optional abbreviated publication name.
publication: ""
publication_short: ""

abstract: "This paper shows that the benchmark-adjusted return of active equity funds is time-varying and highly predictable with the average level of stock idiosyncratic volatilities in the cross-section, the so-called Aggregate Idiosyncratic Volatility (AIV). Using the sample of active US equity mutual funds from 1984 to 2020, we document that AIV positively predicts benchmark-adjusted fund returns, and its predictive power is stronger for funds deviating more from their benchmarks. In addition, we find that this phenomenon is prevalent around the world using a comprehensive sample of international equity mutual funds. Our preferred explanation for these findings is that AIV decreases the risk-bearing capacity of active funds so they require higher rewards for bearing larger tracking errors. Additional tests largely support our story. First, the effect of unexpected AIV on contemporaneous benchmark adjusted returns is negative. Second, on average, funds scale back active positions and reduce liquidity provision activity when AIV rises. Third, funds that trade against past stock price movements earn greater returns following high AIV levels. Overall, our paper answers a critical question: when will active funds generate outperformance for their clients?"

# Summary. An optional shortened abstract.
summary: "Active fund managers outperform their benchmarks only when individual stock idiosyncratic volatilities are high simultaneously."

tags: [Active Funds, Idiosyncratic Volatility, Asset pricing]
categories: []
featured: true

# Custom links (optional).
#   Uncomment and edit lines below to show custom links.
# links:
# - name: Follow
#   url: https://twitter.com
#   icon_pack: fab
#   icon: twitter

url_pdf: files/AIV_ActiveFunds.pdf
url_code:
url_dataset:
url_poster:
url_project:
url_slides:
url_source:
url_video:

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
# Placement options: 1 = Full column width, 2 = Out-set, 3 = Screen-width
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  placement: 1
  caption: ""
  focal_point: "Center"
  preview_only: true

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: []

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ""
---
